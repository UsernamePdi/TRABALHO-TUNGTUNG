if (oControle.estado != "perguntando") {
    tempo_em_cima = 0;
    exit;
}

if (place_meeting(x, y, oPlayer)) {
    tempo_em_cima += delta_time / 1000000;   // soma em segundos

    if (tempo_em_cima >= global.tempo_escolha) {
        tempo_em_cima = 0;
        oControle.responder(indice_alt);
    }
} else {
    tempo_em_cima = 0;   // saiu de cima: zera a contagem
}