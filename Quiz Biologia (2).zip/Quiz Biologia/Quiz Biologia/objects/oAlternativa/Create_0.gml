indice_alt    = 0;   // 0 = A, 1 = B, 2 = C, 3 = D
tempo_em_cima = 0;   // segundos que o player está em cima