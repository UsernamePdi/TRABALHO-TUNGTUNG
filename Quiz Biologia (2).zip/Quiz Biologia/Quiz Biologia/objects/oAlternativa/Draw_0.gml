var _p = oControle.perguntas[oControle.indice];

// depois da resposta: certa = verde, errada escolhida = vermelha
image_blend = c_white;
if (oControle.estado == "resultado") {
    if (indice_alt == _p.correta)               image_blend = c_lime;
    else if (indice_alt == oControle.escolhida) image_blend = c_red;
    else                                        image_blend = c_gray;
}
draw_self();

// barrinha de progresso dos 3 segundos
if (tempo_em_cima > 0) {
    var _pct = tempo_em_cima / global.tempo_escolha * 100;
    draw_healthbar(bbox_left - 6, bbox_top - 10, bbox_right + 6, bbox_top - 4,
                   _pct, c_black, c_yellow, c_lime, 0, true, true);
}

// texto da alternativa
draw_set_color(c_white);
draw_set_halign(fa_center);
draw_set_valign(fa_bottom);
draw_text_ext((bbox_left + bbox_right) / 2, bbox_top - 14, _p.alt[indice_alt], 14, 110);
draw_set_halign(fa_left);
draw_set_valign(fa_top);