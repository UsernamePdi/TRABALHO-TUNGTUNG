if (place_meeting(x, y, oPlayer)) {
    sprite_index  = sprite_over;
    timer_pressed = tempo_pressed;
} else {
    if (timer_pressed > 0) {
        timer_pressed--;
        sprite_index = sprite_pressed;
    } else {
        sprite_index = sprite_normal;
    }
}