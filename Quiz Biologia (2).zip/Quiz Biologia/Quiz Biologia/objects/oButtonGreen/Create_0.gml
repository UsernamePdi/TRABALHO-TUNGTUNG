sprite_normal  = sButtonGreen;
sprite_over    = sButtonOVER;
sprite_pressed = sButtonPressed;
mask_index     = sButtonGreen;

tempo_pressed  = 10;
timer_pressed  = 0;