tempo_max = 10;            // segundos para responder cada pergunta
tempo = tempo_max;

// posição no array = número mostrado (sTimer = 00, sTimer1 = 01, ... sTimer10 = 10)
spr_timer = [sTimer, sTimer1, sTimer2, sTimer3, sTimer4, sTimer5,
             sTimer6, sTimer7, sTimer8, sTimer9, sTimer10];