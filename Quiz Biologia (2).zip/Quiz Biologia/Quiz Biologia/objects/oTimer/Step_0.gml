if (oControle.estado == "perguntando") {
    tempo -= delta_time / 1000000;

    if (tempo <= 0) {
        tempo = 0;
        oControle.responder(-1);   // tempo esgotado = errou
    }
}

// mostra o sprite do número certo (10 aparece no primeiro segundo inteiro)
sprite_index = spr_timer[clamp(ceil(tempo), 0, 10)];