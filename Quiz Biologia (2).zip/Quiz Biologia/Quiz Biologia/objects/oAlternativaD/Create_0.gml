  event_inherited();
  indice_alt = 3;