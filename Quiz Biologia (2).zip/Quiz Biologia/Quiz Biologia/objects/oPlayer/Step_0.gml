if (keyboard_check_direct(ord("D"))) {
    x += 1;
}
if (keyboard_check_direct(ord("A"))) {
    x -= 1;
}
// limita o player dentro da room
x = clamp(x, sprite_xoffset, room_width - (sprite_get_width(sprite_index) - sprite_xoffset));
y = clamp(y, sprite_yoffset, room_height - (sprite_get_height(sprite_index) - sprite_yoffset));