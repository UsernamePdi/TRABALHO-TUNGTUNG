draw_self();
var _p = oControle.perguntas[oControle.indice];

draw_set_color(c_black);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_text_ext(bbox_left + 16, bbox_top + 16, _p.texto, 18, (bbox_right - bbox_left) - 32);
draw_set_color(c_white);