if (estado == "fim" && keyboard_check_pressed(vk_enter)) {
    room_restart();
}