draw_set_color(c_white);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_text(10, 10, "Pontos: " + string(pontos));

if (estado == "fim") {
    draw_set_alpha(0.85);
    draw_set_color(c_black);
    draw_rectangle(0, 0, room_width, room_height, false);
    draw_set_alpha(1);

    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_text(room_width / 2, room_height / 2,
        "Fim do quiz!\nVocê fez " + string(pontos) + " de " + string(array_length(perguntas)) +
        " pontos\n\nENTER para jogar de novo");

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}