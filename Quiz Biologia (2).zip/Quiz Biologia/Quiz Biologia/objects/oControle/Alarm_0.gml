if (indice + 1 >= array_length(perguntas)) {
    estado = "fim";
} else {
    indice++;
    escolhida = -1;
    estado = "perguntando";
    with (oTimer) tempo = tempo_max;   // reinicia o timer
}