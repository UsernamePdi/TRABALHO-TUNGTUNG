// ---------- JANELA ----------
window_set_size(900, 600);
window_center();

// ---------- CONFIG ----------
depth = -1000;                 // desenha por cima de tudo
global.tempo_escolha = 3;      // segundos em cima da alternativa

// ---------- PERGUNTAS ----------
// correta: 0 = A, 1 = B, 2 = C, 3 = D
perguntas = [
    { texto: "Qual organela é responsável pela respiração celular?",
      alt: ["Ribossomo", "Mitocôndria", "Lisossomo", "Golgi"], correta: 1 },

    { texto: "Qual processo as plantas usam para produzir glicose?",
      alt: ["Fotossíntese", "Digestão", "Fermentação", "Osmose"], correta: 0 },

    { texto: "Qual molécula guarda a informação genética?",
      alt: ["Glicose", "Proteína", "DNA", "Lipídio"], correta: 2 },

    { texto: "Qual estrutura controla a entrada e saída de substâncias da célula?",
      alt: ["Parede celular", "Núcleo", "Citoplasma", "Membrana plasmática"], correta: 3 },

    { texto: "Qual pigmento dá a cor verde às plantas?",
      alt: ["Clorofila", "Melanina", "Hemoglobina", "Caroteno"], correta: 0 },

    { texto: "Qual destes seres é um produtor na cadeia alimentar?",
      alt: ["Leão", "Capim", "Fungo", "Sapo"], correta: 1 },

    { texto: "Quantos cromossomos tem uma célula humana normal?",
      alt: ["23", "44", "46", "48"], correta: 2 },

    { texto: "Qual sistema do corpo transporta o sangue?",
      alt: ["Digestório", "Respiratório", "Nervoso", "Circulatório"], correta: 3 },

    { texto: "Qual é a unidade básica da vida?",
      alt: ["Célula", "Átomo", "Órgão", "Tecido"], correta: 0 },

    { texto: "Qual gás as plantas absorvem na fotossíntese?",
      alt: ["Oxigênio", "Gás carbônico", "Nitrogênio", "Hidrogênio"], correta: 1 }
];

// ---------- SPRITES DOS NÚMEROS DAS PERGUNTAS ----------
// (nomes exatos dos seus assets)
spr_numeros = [sQuestion1, sQuestion2, sQuestion3, SQuestion4, sQeustion5,
               sQuestion6, sQuestion7, sQuestion8, sQuestion9, sQuestion10];

// ---------- ESTADO ----------
indice    = 0;                 // pergunta atual
pontos    = 0;
escolhida = -1;
estado    = "perguntando";     // "perguntando" | "resultado" | "fim"

// ---------- FUNÇÃO DE RESPONDER ----------
// _escolha: 0 a 3 = alternativa, -1 = tempo esgotado
responder = function(_escolha) {
    if (estado != "perguntando") return;

    escolhida = _escolha;
    estado = "resultado";

    if (_escolha == perguntas[indice].correta) {
        pontos++;
        // sprite de ponto aparece em cima do player
        instance_create_depth(oPlayer.x, oPlayer.y - 40, -500, oPonto);
    }

    alarm[0] = 120; // 2 segundos mostrando o resultado (60 fps)
};