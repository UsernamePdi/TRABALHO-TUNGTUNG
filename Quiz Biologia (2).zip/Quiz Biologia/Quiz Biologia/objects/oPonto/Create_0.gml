vspeed = -0.5;
alarm[0] = 90;